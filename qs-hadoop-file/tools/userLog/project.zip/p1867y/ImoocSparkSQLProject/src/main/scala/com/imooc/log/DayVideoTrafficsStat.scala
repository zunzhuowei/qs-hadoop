package com.imooc.log

case class DayVideoTrafficsStat(day:String,cmsId:Long,traffics:Long)
